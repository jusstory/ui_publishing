# jquery-minimap
A jQuery plugin that creates an interactive minimap of an element and its children.

##Demo
https://john-bai.github.io/jquery-minimap

##Usage
```javascript
$( "#minimap" ).minimap( $element );
```